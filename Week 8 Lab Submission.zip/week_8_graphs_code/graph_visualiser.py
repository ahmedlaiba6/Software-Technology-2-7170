from graph import Graph
import tkinter as tk
from tkinter import simpledialog, messagebox
import math
import time
import threading


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.geometry("700x650")

        self.graph = graph
        self.canvas = tk.Canvas(self, width=650, height=500, bg="white")
        self.canvas.pack(pady=10)

        self.vertex_positions = {}
        self.vertex_items = {}
        self.edge_items = {}

        self.create_controls()
        self.draw_graph()

    def create_controls(self):
        control_frame = tk.Frame(self)
        control_frame.pack(pady=10)

        tk.Button(control_frame, text="Add Vertex", command=self.add_vertex_gui).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(control_frame, text="Remove Vertex", command=self.remove_vertex_gui).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(control_frame, text="Add Edge", command=self.add_edge_gui).grid(row=0, column=2, padx=5, pady=5)
        tk.Button(control_frame, text="Remove Edge", command=self.remove_edge_gui).grid(row=0, column=3, padx=5, pady=5)

        tk.Button(control_frame, text="Run BFS", command=self.run_bfs).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(control_frame, text="Run DFS", command=self.run_dfs).grid(row=1, column=1, padx=5, pady=5)
        tk.Button(control_frame, text="Reset Highlight", command=self.draw_graph).grid(row=1, column=2, padx=5, pady=5)

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions.clear()
        self.vertex_items.clear()
        self.edge_items.clear()

        radius = 20
        spacing = 170
        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 325, 240

        # Draw vertices in a circle
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

            oval = self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill="lightblue", outline="black", width=2
            )
            text = self.canvas.create_text(x, y, text=v, font=("Arial", 11, "bold"))
            self.vertex_items[v] = (oval, text)

        # Draw edges
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                line = self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None,
                    width=2
                )
                self.edge_items[(v, nbr)] = line

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red", font=("Arial", 10, "italic"))

    def highlight_vertex(self, vertex, color="yellow"):
        if vertex in self.vertex_items:
            oval, _ = self.vertex_items[vertex]
            self.canvas.itemconfig(oval, fill=color)
            self.update()

    def highlight_edge(self, v1, v2, color="orange"):
        if (v1, v2) in self.edge_items:
            self.canvas.itemconfig(self.edge_items[(v1, v2)], fill=color, width=3)
            self.update()

    def add_vertex_gui(self):
        vertex = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if vertex:
            self.graph.add_vertex(vertex)
            self.draw_graph()

    def remove_vertex_gui(self):
        vertex = simpledialog.askstring("Remove Vertex", "Enter vertex name to remove:")
        if vertex:
            self.graph.remove_vertex(vertex)
            self.draw_graph()

    def add_edge_gui(self):
        v1 = simpledialog.askstring("Add Edge", "Enter start vertex:")
        v2 = simpledialog.askstring("Add Edge", "Enter end vertex:")
        if not v1 or not v2:
            return

        weight = 0
        if self.graph.weighted:
            weight_input = simpledialog.askstring("Add Edge", "Enter weight:")
            try:
                weight = int(weight_input)
            except (TypeError, ValueError):
                messagebox.showerror("Invalid Input", "Weight must be an integer.")
                return

        self.graph.add_edge(v1, v2, weight)
        self.draw_graph()

    def remove_edge_gui(self):
        v1 = simpledialog.askstring("Remove Edge", "Enter start vertex:")
        v2 = simpledialog.askstring("Remove Edge", "Enter end vertex:")
        if v1 and v2:
            self.graph.remove_edge(v1, v2)
            self.draw_graph()

    def run_bfs(self):
        start = simpledialog.askstring("Run BFS", "Enter start vertex:")
        if not start or start not in self.graph.graph:
            messagebox.showerror("Invalid Input", "Start vertex not found.")
            return

        threading.Thread(target=self.animate_bfs, args=(start,), daemon=True).start()

    def animate_bfs(self, start_vertex):
        self.draw_graph()
        visited = {start_vertex}
        queue = [start_vertex]

        while queue:
            vertex = queue.pop(0)
            self.highlight_vertex(vertex, "yellow")
            time.sleep(0.6)

            for neighbor in self.graph.graph[vertex]:
                if neighbor not in visited:
                    self.highlight_edge(vertex, neighbor, "orange")
                    visited.add(neighbor)
                    queue.append(neighbor)
                    time.sleep(0.4)

    def run_dfs(self):
        start = simpledialog.askstring("Run DFS", "Enter start vertex:")
        if not start or start not in self.graph.graph:
            messagebox.showerror("Invalid Input", "Start vertex not found.")
            return

        threading.Thread(target=self.animate_dfs, args=(start,), daemon=True).start()

    def animate_dfs(self, start_vertex):
        self.draw_graph()
        visited = set()
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.add(vertex)
                self.highlight_vertex(vertex, "lightgreen")
                time.sleep(0.6)

                for neighbor in reversed(self.graph.graph[vertex]):
                    if neighbor not in visited:
                        self.highlight_edge(vertex, neighbor, "purple")
                        stack.append(neighbor)
                        time.sleep(0.4)


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)

    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_vertex('D')

    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'D', 30)
    g.add_edge('A', 'D', 40)

    app = GraphVisualizer(g)
    app.mainloop()