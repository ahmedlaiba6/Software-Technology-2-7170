from graph import Graph

# =========================
# Task 1: Undirected Graph
# =========================
print("UNDIRECTED GRAPH TEST")
g = Graph()

g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

print("After adding vertices A, B, C, D:")
g.print_graph()
print()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

print("After adding edges A-B, B-C, C-D:")
g.print_graph()
print()


# =========================
# Task 1: Directed Graph
# =========================
print("DIRECTED GRAPH TEST")
directed_g = Graph(directed=True)

directed_g.add_vertex('A')
directed_g.add_vertex('B')
directed_g.add_vertex('C')
directed_g.add_vertex('D')

print("After adding vertices A, B, C, D:")
directed_g.print_graph()
print()

directed_g.add_edge('A', 'B')
directed_g.add_edge('B', 'C')
directed_g.add_edge('C', 'D')

print("After adding directed edges A->B, B->C, C->D:")
directed_g.print_graph()
print()


# =========================
# Task 1: Removal Test
# =========================
print("REMOVAL TEST")
removal_test = Graph()

removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')

print("Original graph:")
removal_test.print_graph()
print()

removal_test.remove_edge('A', 'B')
print("After removing edge A-B:")
removal_test.print_graph()
print()

removal_test.remove_vertex('C')
print("After removing vertex C:")
removal_test.print_graph()
print()


# =========================
# Task 2 + Task 3 Graph
# =========================
print("BFS AND DFS TEST GRAPH")

g.add_vertex('E')
g.add_vertex('F')

g.add_edge('A', 'E')
g.add_edge('B', 'F')

print("Graph structure before BFS and DFS:")
g.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()

print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()


# =========================
# Task 4: Cycle Detection
# =========================
print("CYCLE DETECTION TEST")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Cycle graph structure:")
cycle_graph.print_graph()
print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())
print()

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Acyclic graph structure:")
acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())
print()


# =========================
# Task 5: Weighted Directed Graph
# =========================
print("WEIGHTED DIRECTED GRAPH TEST")

wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
print()