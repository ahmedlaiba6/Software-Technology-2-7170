class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)

            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)

                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print("Edge not present in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            edges_to_remove = []

            for k in self.graph:
                for v in self.graph[k]:
                    if v == vertex:
                        edges_to_remove.append((k, v))

            for e in edges_to_remove:
                self.remove_edge(e[0], e[1])

            # remove weights related to this vertex
            if self.weighted:
                keys_to_delete = []
                for edge in self.weights:
                    if edge[0] == vertex or edge[1] == vertex:
                        keys_to_delete.append(edge)

                for key in keys_to_delete:
                    del self.weights[key]

            del self.graph[vertex]
        else:
            print("Vertex not present in graph.")

    def print_graph(self):
        for vertex in self.graph:
            if len(self.graph[vertex]) == 0:
                print(vertex)
            else:
                edges = []
                for neighbor in self.graph[vertex]:
                    if self.weighted:
                        weight = self.weights.get((vertex, neighbor), 0)
                        edges.append(f"{neighbor}({weight})")
                    else:
                        edges.append(neighbor)

                if self.directed:
                    print(f"{vertex} --> {' '.join(edges)}")
                else:
                    print(f"{vertex} --- {' '.join(edges)}")

    # BFS
    def bfs(self, start_vertex):
        visited = {start_vertex}
        queue = [start_vertex]

        while queue:
            vertex = queue.pop(0)
            print(vertex, end=' ')

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    queue.append(neighbor)
                    visited.add(neighbor)

        print()
        return visited

    # DFS
    def dfs(self, start_vertex):
        visited = set()
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.add(vertex)
                print(vertex, end=' ')

                for neighbor in self.graph[vertex]:
                    if neighbor not in visited:
                        stack.append(neighbor)

        print()
        return visited

    # Cycle detection (undirected)
    def cycle_dfs(self, current_vertex, visited, parent_vertex):
        visited.add(current_vertex)

        for neighbor in self.graph[current_vertex]:
            if neighbor not in visited:
                if self.cycle_dfs(neighbor, visited, current_vertex):
                    return True
            elif parent_vertex != neighbor:
                return True

        return False

    def has_undirected_cycle(self):
        visited = set()

        for vertex in self.graph:
            if vertex not in visited:
                if self.cycle_dfs(vertex, visited, None):
                    return True

        return False