import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 60
NODE_HEIGHT = 40
HORIZONTAL_GAP = 20

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SingleLinkedList:
    def __init__(self):
        self.head = None

    def insert(self, index, value):
        new_node = Node(value)
        if index == 0:
            new_node.next = self.head
            self.head = new_node
            return

        temp = self.head
        for _ in range(index - 1):
            if temp is None:
                return
            temp = temp.next

        if temp:
            new_node.next = temp.next
            temp.next = new_node

    def delete(self, value):
        temp = self.head

        if temp and temp.data == value:
            self.head = temp.next
            return

        prev = None
        while temp and temp.data != value:
            prev = temp
            temp = temp.next

        if temp:
            prev.next = temp.next

    def search(self, value):
        temp = self.head
        index = 0
        while temp:
            if temp.data == value:
                return index
            temp = temp.next
            index += 1
        return -1

    def to_list(self):
        result = []
        temp = self.head
        while temp:
            result.append(temp.data)
            temp = temp.next
        return result


class SLLVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Single Linked List Visualizer")

        self.sll = SingleLinkedList()

        self.canvas = tk.Canvas(root, width=700, height=200, bg="white")
        self.canvas.pack(pady=20)

        frame = tk.Frame(root)
        frame.pack()

        tk.Label(frame, text="Insert Value:").grid(row=0, column=0)
        self.insert_val = tk.Entry(frame, width=5)
        self.insert_val.grid(row=0, column=1)

        tk.Label(frame, text="at Index:").grid(row=0, column=2)
        self.insert_index = tk.Entry(frame, width=5)
        self.insert_index.grid(row=0, column=3)

        tk.Button(frame, text="Insert", command=self.insert).grid(row=0, column=4)

        tk.Label(frame, text="Delete Value:").grid(row=1, column=0)
        self.delete_val = tk.Entry(frame, width=5)
        self.delete_val.grid(row=1, column=1)

        tk.Button(frame, text="Delete", command=self.delete).grid(row=1, column=4)

        tk.Label(frame, text="Search Value:").grid(row=2, column=0)
        self.search_val = tk.Entry(frame, width=5)
        self.search_val.grid(row=2, column=1)

        tk.Button(frame, text="Search", command=self.search).grid(row=2, column=4)

        self.status = tk.Label(root, text="", fg="blue")
        self.status.pack()

    def draw(self):
        self.canvas.delete("all")
        values = self.sll.to_list()

        x = 20
        y = 80

        for i, val in enumerate(values):
            self.canvas.create_rectangle(x, y, x+NODE_WIDTH, y+NODE_HEIGHT)
            self.canvas.create_text(x+30, y+20, text=str(val))

            if i < len(values) - 1:
                self.canvas.create_line(x+NODE_WIDTH, y+20, x+NODE_WIDTH+HORIZONTAL_GAP, y+20, arrow=tk.LAST)

            x += NODE_WIDTH + HORIZONTAL_GAP

    def insert(self):
        try:
            val = int(self.insert_val.get())
            index = int(self.insert_index.get())
            self.sll.insert(index, val)
            self.status.config(text=f"Inserted {val} at index {index}")
            self.draw()
        except:
            messagebox.showerror("Error", "Invalid input")

    def delete(self):
        try:
            val = int(self.delete_val.get())
            self.sll.delete(val)
            self.status.config(text=f"Deleted {val}")
            self.draw()
        except:
            messagebox.showerror("Error", "Invalid input")

    def search(self):
        try:
            val = int(self.search_val.get())
            result = self.sll.search(val)
            if result != -1:
                self.status.config(text=f"Found {val} at index {result}")
            else:
                self.status.config(text=f"{val} not found")
        except:
            messagebox.showerror("Error", "Invalid input")


if __name__ == "__main__":
    root = tk.Tk()
    app = SLLVisualizer(root)
    root.mainloop()