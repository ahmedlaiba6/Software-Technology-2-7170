import tkinter as tk
from tkinter import messagebox, ttk
import time
import random
import string


# ==========================================
# BST
# ==========================================

class BSTNode:
    def __init__(self, key, phone=None):
        self.key = key
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, key, phone):
        if root is None:
            return BSTNode(key, phone)
        if key < root.key:
            root.left = self.insert(root.left, key, phone)
        elif key > root.key:
            root.right = self.insert(root.right, key, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, key):
        if root is None or root.key == key:
            return root
        if key < root.key:
            return self.search(root.left, key)
        return self.search(root.right, key)


# ==========================================
# AVL
# ==========================================

class AVLNode:
    def __init__(self, key, phone):
        self.key = key
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def right_rotate(self, z):
        y = z.left
        t3 = y.right

        y.right = z
        z.left = t3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left

        y.left = z
        z.right = t2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, key, phone):
        if not node:
            return AVLNode(key, phone)

        if key < node.key:
            node.left = self.insert(node.left, key, phone)
        elif key > node.key:
            node.right = self.insert(node.right, key, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and key < node.left.key:
            return self.right_rotate(node)
        if balance < -1 and key > node.right.key:
            return self.left_rotate(node)
        if balance > 1 and key > node.left.key:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and key < node.right.key:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def search(self, node, key):
        if node is None or node.key == key:
            return node
        if key < node.key:
            return self.search(node.left, key)
        return self.search(node.right)


# ==========================================
# RED-BLACK TREE
# ==========================================

RED = "red"
BLACK = "black"


class RBNode:
    def __init__(self, key=None, phone=None, color=RED):
        self.key = key
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(color=BLACK)
        self.root = self.NIL

    def search(self, node, key):
        if node == self.NIL or key == node.key:
            return node
        if key < node.key:
            return self.search(node.left, key)
        return self.search(node.right, key)

    def left_rotate(self, x):
        y = x.right
        x.right = y.left

        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent

        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right

        if x.right != self.NIL:
            x.right.parent = y

        x.parent = y.parent

        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, key, phone):
        node = RBNode(key, phone, RED)
        node.left = self.NIL
        node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if node.key < current.key:
                current = current.left
            elif node.key > current.key:
                current = current.right
            else:
                current.phone = phone
                return

        node.parent = parent

        if parent is None:
            self.root = node
        elif node.key < parent.key:
            parent.left = node
        else:
            parent.right = node

        if node.parent is None:
            node.color = BLACK
            return

        if node.parent.parent is None:
            return

        self.fix_insert(node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == RED:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left  # uncle
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right  # uncle
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)

            if k == self.root:
                break

        self.root.color = BLACK

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if node != self.NIL:
            self.inorder(node.left, result)
            result.append((node.key, node.phone, node.color))
            self.inorder(node.right, result)
        return result


# ==========================================
# GUI VISUALISER FOR RED-BLACK TREE
# ==========================================

class RedBlackApp:
    def __init__(self, master):
        self.tree = RedBlackTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")
        master.geometry("950x700")

        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1)

        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Show All", command=self.show_all).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Benchmark", command=self.run_benchmark).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=10, width=80)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=900, height=450, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return

        self.tree.insert(name, phone)
        messagebox.showinfo("Success", f"Inserted/Updated contact: {name}")
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Please enter a name to search.")
            return

        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)

        if node != self.tree.NIL:
            self.output_text.insert(
                tk.END,
                f"Found Contact:\nName: {node.key}\nPhone: {node.phone}\nColor: {node.color}\n"
            )
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)
        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone, color in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}, Color: {color}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        self._draw_node(self.tree.root, 450, 40, 220)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.tree.NIL:
            return

        radius = 22

        if node.left != self.tree.NIL:
            x_left = x - x_offset
            y_left = y + 80
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, max(x_offset // 2, 45))

        if node.right != self.tree.NIL:
            x_right = x + x_offset
            y_right = y + 80
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, max(x_offset // 2, 45))

        fill_color = "red" if node.color == RED else "black"
        text_color = "white" if node.color == BLACK else "black"

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color, outline="black")
        display_name = node.key if len(node.key) <= 8 else node.key[:8] + "..."
        self.canvas.create_text(x, y, text=display_name, fill=text_color, font=("Arial", 9, "bold"))

    def run_benchmark(self):
        sizes = [100, 500, 1000]
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, "Benchmark Results (BST vs AVL vs Red-Black)\n\n")

        for n in sizes:
            names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
            phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

            # BST
            bst = BST()
            start = time.time()
            for i in range(n):
                bst.root = bst.insert(bst.root, names[i], phones[i])
            bst_insert = time.time() - start

            start = time.time()
            for name in names[:100]:
                bst.search(bst.root, name)
            bst_search = time.time() - start

            # AVL
            avl = AVLTree()
            start = time.time()
            for i in range(n):
                avl.root = avl.insert(avl.root, names[i], phones[i])
            avl_insert = time.time() - start

            start = time.time()
            for name in names[:100]:
                avl.search(avl.root, name)
            avl_search = time.time() - start

            # RB
            rb = RedBlackTree()
            start = time.time()
            for i in range(n):
                rb.insert(names[i], phones[i])
            rb_insert = time.time() - start

            start = time.time()
            for name in names[:100]:
                rb.search(rb.root, name)
            rb_search = time.time() - start

            self.output_text.insert(
                tk.END,
                f"n = {n}\n"
                f"BST  -> Insert: {bst_insert:.6f}s, Search: {bst_search:.6f}s\n"
                f"AVL  -> Insert: {avl_insert:.6f}s, Search: {avl_search:.6f}s\n"
                f"RBT  -> Insert: {rb_insert:.6f}s, Search: {rb_search:.6f}s\n\n"
            )


# ==========================================
# MAIN
# ==========================================

if __name__ == "__main__":
    root = tk.Tk()
    app = RedBlackApp(root)
    root.mainloop()