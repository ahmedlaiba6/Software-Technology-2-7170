import timeit

# ---------------------------------
# RECURSIVE VERSIONS
# ---------------------------------

def sum_recursive(n):
    if n == 1:
        return 1
    return n + sum_recursive(n - 1)

def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n - 1)


# ---------------------------------
# ITERATIVE VERSIONS
# ---------------------------------

def sum_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result


# ---------------------------------
# TEST OUTPUTS
# ---------------------------------

print("=== TASK 1: RECURSION VS ITERATION ===\n")

print("Sum of first 5 natural numbers")
print("Recursive:", sum_recursive(5))
print("Iterative:", sum_iterative(5))
print()

print("7th Fibonacci number")
print("Recursive:", fibonacci_recursive(7))
print("Iterative:", fibonacci_iterative(7))
print()

print("Factorial of 5")
print("Recursive:", factorial_recursive(5))
print("Iterative:", factorial_iterative(5))
print()


# ---------------------------------
# TIME COMPARISONS
# ---------------------------------

test_sizes = [5, 10, 15]

for n in test_sizes:
    print(f"--- Testing n = {n} ---")

    sum_recursive_time = timeit.timeit(lambda: sum_recursive(n), number=1000)
    sum_iterative_time = timeit.timeit(lambda: sum_iterative(n), number=1000)

    fibonacci_recursive_time = timeit.timeit(lambda: fibonacci_recursive(n), number=100)
    fibonacci_iterative_time = timeit.timeit(lambda: fibonacci_iterative(n), number=100)

    factorial_recursive_time = timeit.timeit(lambda: factorial_recursive(n), number=1000)
    factorial_iterative_time = timeit.timeit(lambda: factorial_iterative(n), number=1000)

    print(f"Sum Recursive Time: {sum_recursive_time:.6f} seconds")
    print(f"Sum Iterative Time: {sum_iterative_time:.6f} seconds")
    print(f"Fibonacci Recursive Time: {fibonacci_recursive_time:.6f} seconds")
    print(f"Fibonacci Iterative Time: {fibonacci_iterative_time:.6f} seconds")
    print(f"Factorial Recursive Time: {factorial_recursive_time:.6f} seconds")
    print(f"Factorial Iterative Time: {factorial_iterative_time:.6f} seconds")
    print()