move_count = 0

def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)


def run_hanoi(n):
    global move_count
    move_count = 0
    
    print("\nEnter number of disks:", n)
    print("The moves are:")
    
    moveDisks(n, 'A', 'B', 'C')
    
    print("Number of moves is", move_count)


# Run for TWO different sizes (REQUIRED)
run_hanoi(3)
run_hanoi(4)