from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 500
        self.height = 500

        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        p1 = [self.width / 2, 50]
        p2 = [80, self.height - 120]
        p3 = [self.width - 80, self.height - 120]

        self.drawKoch(int(self.order.get()), p1, p2)
        self.drawKoch(int(self.order.get()), p2, p3)
        self.drawKoch(int(self.order.get()), p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            x1, y1 = p1
            x5, y5 = p2

            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3

            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3

            angle = math.pi / 3
            dx = x4 - x2
            dy = y4 - y2

            x3 = x2 + dx * math.cos(angle) - dy * math.sin(angle)
            y3 = y2 + dx * math.sin(angle) + dy * math.cos(angle)

            pA = [x1, y1]
            pB = [x2, y2]
            pC = [x3, y3]
            pD = [x4, y4]
            pE = [x5, y5]

            self.drawKoch(order - 1, pA, pB)
            self.drawKoch(order - 1, pB, pC)
            self.drawKoch(order - 1, pC, pD)
            self.drawKoch(order - 1, pD, pE)

KochSnowflake()